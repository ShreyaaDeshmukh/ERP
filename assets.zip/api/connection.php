<?php

	$con = mysqli_connect("localhost","u111036982_cm","t7SRgGY6QClN","u111036982_cm");

	if (mysqli_connect_errno())

  	{

  		echo "Failed to connect to MySQL: " . mysqli_connect_error();die();

  	}

  	/*else{

  		echo 'connect';

  	}*/

?>



