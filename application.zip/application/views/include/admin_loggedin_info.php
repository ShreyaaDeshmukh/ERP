<ul class="nav pull-right">
	<li class="dropdown" style="float:right;">
		<a href="#" class="dropdown-toggle" data-toggle="dropdown">{email}<b class="caret"></b></a>
		<ul class="dropdown-menu">
			<li><a href="<?php echo base_url('Admin_dashboard/edit_profile');?>" >Edit Profile</a></li>
			<li><a href="<?php echo base_url('Admin_dashboard/change_password_form');?>" >Change Password</a></li>	
			<li><a href="{logout}" >Logout</a></li>
		</ul>
	</li>
</ul>