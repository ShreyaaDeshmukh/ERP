<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

    class User extends CI_Controller {

    public $user_id;

    function __construct() {
        parent::__construct();
        $this->load->model('users');
        $this->load->library('auth');
        $this->load->library('lusers');
        $this->load->library('session');
        $this->load->model('Userm');
        // $this->auth->check_admin_auth();
        $this->template->current_menu = 'settings';

        if ($this->session->userdata('user_type') == '2') {
            $this->session->set_userdata(array('error_message' => display('you_are_not_access_this_part')));
            redirect('Admin_dashboard');
        }
		
		$this->load->model('Web_settings');
		$this->Web_settings->checkLicensing();
    }

    #==============User page load============#

    public function index() {
        // print_r($this->session-);die;
        if (!$this->session->username){
            $this->output->set_header("Location: " . base_url() . 'Admin_dashboard/login', TRUE, 302);
            // $this->auth->check_admin_auth();
        }
       else{
         // echo ($content);exit;
        $content = $this->lusers->user_add_form();
       
        $this->template->full_admin_html_view($content);
       }
    }

    #===============User Search Item===========#

    public function user_search_item() {
        $user_id = $this->input->post('user_id');
        $content = $this->lusers->user_search_item($user_id);
        $this->template->full_admin_html_view($content);
    }

    #================Manage User===============#

    public function manage_user() {
        if (!$this->session->username){
            $this->output->set_header("Location: " . base_url() . 'Admin_dashboard/login', TRUE, 302);
            // $this->auth->check_admin_auth();
        }
       else{
        $content = $this->lusers->user_list();
        $this->template->full_admin_html_view($content);
       }
    }

    #==============Insert User==============#

    public function insert_user() {
      
        $this->load->model('userm');
        $email = $this->session->userdata('username'); 
        // print_r($this->session->r_id);die;    
        $result = $this->users->check_email($email);


        $l_key='';
       
        // $this->session->get_userdata($user_login);

        // $email = $this->session->userdata('username'); 

        // foreach($result as $row){ 
        //  $r_id= $row->r_id;
        // }

        // $this->session->set_userdata('register_id',$r_id);

        $owner_id=$this->session->r_id;

        $con=mysqli_connect("localhost", "root","","wholesale");

        $sql = "SELECT * from license_key where user_id=$owner_id and is_assigned=0";
        $result = $con->query($sql);

        // echo $owner_id;

        // echo $result;
        
        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
          $l_key= $row['license_key'];  
           
            $data = array(
                'register_id'  =>$this->session->r_id,
                'user_id' => $this->generator(15),
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'mobile' => $this->input->post('mobile'),
                'license_key'=>$l_key,
                'email' => $this->input->post('email'),
                'device_type'=>$this->input->post('platform'),
                'password' => md5("gef" . $this->input->post('password')),
                'create_date_time'=>date('Y-m-d H:i:s')
            
            );
   
            $result=$this->userm->user_entry($data);
             //echo 1;  
                  
            if($result=='already email exist'){ 
                $this->session->set_flashdata('data_msg',"already email exists");
               //   $data_msg="alreadyemail_exists";
                 redirect(base_url('User'));
                
            }
           //  else if($result=='two user already exists'){
           //       $this->session->set_flashdata('data_msg',"You can not create more then two users.Subscribe to add more users");
           //         //   $data_msg= "two user already exists";
           //           redirect('User/manage_user/',$data_msg);
                     
           //  }
            else{
                $sql = "UPDATE license_key SET is_assigned=1,assigned_user_id=$result where license_key='".$l_key."'";


                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $conn->error;
                  }

                  $this->session->set_flashdata('data_msg',"User created successfully");
               
                  redirect('User/manage_user');
                
            }          }
        } else {
            $this->session->set_flashdata('data_msg',"You can not create more users");
            redirect('User/manage_user/',$data_msg);
        }
        
       
        //  print_r($result);die;  
     
 }
    #===============User update form================#

    public function user_update_form($user_id) {
        $user_id = $user_id;
			 if (!$this->session->userdata('username')){
            $this->output->set_header("Location: " . base_url() . 'Admin_dashboard/login', TRUE, 302);
            // $this->auth->check_admin_auth();
        }
		else{
        $content = $this->lusers->user_edit_data($user_id);
        $this->template->full_admin_html_view($content);
    }
	}

    #===============User update===================#

    public function user_update() {
        $user_id = $this->input->post('user_id');
        // print_r($user_id);die;
        $this->Userm->update_user($user_id);




        $this->session->set_userdata(array('message' => display('successfully_updated')));
        redirect(base_url('User/manage_user'));
    }

    #============User delete===========#

    public function user_delete() {
        // print_R($_GET['user_id']);die;
        // if(isset($_POST['user_id']))
        // {
        //     echo 'Deleted successfully.';
        // }
        // else{
        //     echo 'failed';
        // }
        $user_id = $_POST['user_id'];
        // print_r($user_id);exit;
        $this->Userm->delete_user($user_id);
        $this->session->set_userdata(array('message' => display('successfully_delete')));
        return true;
    }

    // Random Id generator
    public function generator($lenth) {
        $number = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "N", "M", "O", "P", "Q", "R", "S", "U", "V", "T", "W", "X", "Y", "Z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0");

        for ($i = 0; $i < $lenth; $i++) {
            $rand_value = rand(0, 61);
            $rand_number = $number["$rand_value"];

            if (empty($con)) {
                $con = $rand_number;
            } else {
                $con = "$con" . "$rand_number";
            }
        }
        return $con;
    }

}
